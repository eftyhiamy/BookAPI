package model.TheBookDB;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "kind",
    "totalItems",
    "items"
})

public class BookResult {
	 	@JsonProperty("kind")
	    private String kind;
	    @JsonProperty("totalItems")
	    private Integer totalItems;
	    @JsonProperty("items")
	    private List<Item> items;
	    @JsonIgnore
	    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

	    @JsonProperty("kind")
	    public String getKind() {
	        return kind;
	    }

	    @JsonProperty("kind")
	    public void setKind(String kind) {
	        this.kind = kind;
	    }

	    @JsonProperty("totalItems")
	    public Integer getTotalItems() {
	        return totalItems;
	    }

	    @JsonProperty("totalItems")
	    public void setTotalItems(Integer totalItems) {
	        this.totalItems = totalItems;
	    }

	    @JsonProperty("items")
	    public List<Item> getItems() {
	        return items;
	    }

	    @JsonProperty("items")
	    public void setItems(List<Item> items) {
	        this.items = items;
	    }

	    @JsonAnyGetter
	    public Map<String, Object> getAdditionalProperties() {
	        return this.additionalProperties;
	    }

	    @JsonAnySetter
	    public void setAdditionalProperty(String name, Object value) {
	        this.additionalProperties.put(name, value);
	    }
	    @Override
	    public String toString() { 
	    	for (int i = 0; i<this.items.size(); i ++) {
	    		String authors = null;
	    		if (!this.items.get(i).getVolumeInfo().getAuthors().isEmpty()) {
	    		authors = String.join(", ", this.items.get(i).getVolumeInfo().getAuthors());
	    	}
	    		
	    		System.out.println(this.items.get(i).getVolumeInfo().getTitle());
	    		System.out.println(authors);
	    	
	    	}
	    	
	    	return this.kind + this.totalItems;
	    }
}
