package model.listBookshelf;

import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import com.fasterxml.jackson.annotation.JsonAnyGetter;
import com.fasterxml.jackson.annotation.JsonAnySetter;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
    "kind",
    "totalItems",
    "items"
})

public class ListVolumesBookshelf {
	 @JsonProperty("kind")
	    private String kind;
	    @JsonProperty("totalItems")
	    private Integer totalItems;
	    @JsonProperty("items")
	    private List<Item> items;
	    @JsonIgnore
	    private Map<String, Object> additionalProperties = new LinkedHashMap<String, Object>();

	    @JsonProperty("kind")
	    public String getKind() {
	        return kind;
	    }

	    @JsonProperty("kind")
	    public void setKind(String kind) {
	        this.kind = kind;
	    }

	    @Override
		public String toString() {
			return "ListVolumesBookshelf [kind=" + kind + ", totalItems=" + totalItems + ", items=" + items
					+ ", additionalProperties=" + additionalProperties + "]";
		}

		@JsonProperty("totalItems")
	    public Integer getTotalItems() {
	        return totalItems;
	    }

	    @JsonProperty("totalItems")
	    public void setTotalItems(Integer totalItems) {
	        this.totalItems = totalItems;
	    }

	    @JsonProperty("items")
	    public List<Item> getItems() {
	        return items;
	    }

	    @JsonProperty("items")
	    public void setItems(List<Item> items) {
	        this.items = items;
	    }

	    @JsonAnyGetter
	    public Map<String, Object> getAdditionalProperties() {
	        return this.additionalProperties;
	    }

	    @JsonAnySetter
	    public void setAdditionalProperty(String name, Object value) {
	        this.additionalProperties.put(name, value);
	    }
}
