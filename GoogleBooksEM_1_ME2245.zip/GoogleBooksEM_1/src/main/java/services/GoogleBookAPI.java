package services;

public class GoogleBookAPI {

	public static final String API_KEY="your API key";
	public static final String API_URL="www.googleapis.com";
}
