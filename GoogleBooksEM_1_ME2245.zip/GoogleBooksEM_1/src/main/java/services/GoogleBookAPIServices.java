package services;

import java.io.IOException;
import java.io.UnsupportedEncodingException;
import java.net.URI;
import java.net.URLEncoder;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

import org.apache.http.HttpEntity;
import org.apache.http.HttpStatus;
import org.apache.http.client.methods.CloseableHttpResponse;
import org.apache.http.client.methods.HttpGet;
import org.apache.http.client.utils.HttpClientUtils;
import org.apache.http.impl.client.CloseableHttpClient;
import org.apache.http.impl.client.HttpClients;
import org.apache.http.util.EntityUtils;

import com.fasterxml.jackson.databind.ObjectMapper;

import exception.GoogleBookAPIException;
import model.googleBookshelves.userBookshelf;
import model.specificBookshelves.SpecificPublicBookshelf;
import model.listBookshelf.ListVolumesBookshelf;
import model.specificVolume.SpecificVolume;
import model.TheBookDB.BookResult;
import model.TheBookDB.ErrorResponse;

public class GoogleBookAPIServices {

	private final String API_URL;
	private final String API_KEY;
	private static List<String> searchHistory = new ArrayList();

	public GoogleBookAPIServices() {
		this.API_URL = "https://www.googleapis.com";
		this.API_KEY = "your API key";

	}

	
	// 1st Method: Search volumes of books and magazines (volumes), based on specific criteria
	// https://www.googleapis.com/books/v1/volumes?q=search+terms

	public BookResult getVolumes(String bookName, String terms, String specificTerms) throws GoogleBookAPIException, InterruptedException {
		
		String apiBaseUrl = "https://www.googleapis.com/books/v1/volumes";

        // Encode query parameters
        try {
            bookName = URLEncoder.encode(bookName, StandardCharsets.UTF_8.toString());
            if (terms != null && !terms.isEmpty()) {
                terms = URLEncoder.encode(terms, StandardCharsets.UTF_8.toString());
                specificTerms = URLEncoder.encode(specificTerms, StandardCharsets.UTF_8.toString());
            }
        } catch (UnsupportedEncodingException e) {
            throw new GoogleBookAPIException("Error encoding query parameters: " + e.getMessage());
        }

        // Create query parameters
        String query = "q=" + bookName;
        if (terms != null && !terms.isEmpty()) {
            query += "+" + terms + ":" + specificTerms;
        }
        query += "&key=" + API_KEY;

        String uri = apiBaseUrl + "?" + query;

        HttpClient httpClient = HttpClient.newHttpClient();
        HttpRequest request = HttpRequest.newBuilder()
                .uri(URI.create(uri))
                .build();

        try {
            HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
            if (response.statusCode() == 200) {
                String responseBody = response.body();

                ObjectMapper objectMapper = new ObjectMapper();
                BookResult bookResult = objectMapper.readValue(responseBody, BookResult.class);

                return bookResult;
            } else {
                throw new GoogleBookAPIException("Error: Received HTTP status code " + response.statusCode());
            }
        } catch (IOException e) {
            throw new GoogleBookAPIException("Error occurred on API call: " + e.getMessage());
        }
    }
	

	// 2nd Method - Retrieve more information for specific volume
	// https://www.googleapis.com/books/v1/volumes/zyTCAlFPjgYC?key=yourAPIKey
	// https://www.googleapis.com/books/v1/volumes/volumeId
	
	public SpecificVolume getSpecificVolume(String volumeId) throws GoogleBookAPIException, InterruptedException {
		
		String apiBaseUrl = "https://www.googleapis.com/books/v1/volumes/";

        try {
            // Encode the volumeId using URLEncoder
            String encodedVolumeId = URLEncoder.encode(volumeId, "UTF-8");

            // Construct the URL with the encoded volumeTitle and API key
            String uri = apiBaseUrl + encodedVolumeId + "?key=" + API_KEY;

            // Create an HTTP GET request
            HttpGet getRequest = new HttpGet(uri);

            // Create an HTTP client
            CloseableHttpClient httpClient = HttpClients.createDefault();

            try {
                // Execute the GET request
                CloseableHttpResponse response = httpClient.execute(getRequest);

                // Check the response status code
                if (response.getStatusLine().getStatusCode() != 200) {
                    throw new GoogleBookAPIException("Error response from Google Books API: " +
                            response.getStatusLine().getReasonPhrase());
                }

                // Get the response entity
                String responseBody = EntityUtils.toString(response.getEntity());

                // Use Jackson ObjectMapper to parse the JSON response into SpecificVolume object
                ObjectMapper mapper = new ObjectMapper();
                SpecificVolume result = mapper.readValue(responseBody, SpecificVolume.class);

                return result;
            } finally {
                // Close the response and release resources
                HttpClientUtils.closeQuietly(httpClient);
            }
        } catch (UnsupportedEncodingException e) {
            throw new GoogleBookAPIException("Error encoding volume title.", e);
        } catch (IOException e) {
            throw new GoogleBookAPIException("Error requesting data from the Google Books API.", e);
        }
    }
//		String apiBaseUrl = "https://www.googleapis.com/books/v1/volumes/";
//		if (volumeId == null || volumeId.isEmpty()) {
//	        throw new GoogleBookAPIException("Invalid volume ID");
//	    }
//	    
//	    String uri = apiBaseUrl + volumeId + "?key=" + API_KEY;
//	    
//	    HttpClient httpClient = HttpClient.newHttpClient();
//	    HttpRequest request = HttpRequest.newBuilder()
//	            .uri(URI.create(uri))
//	            .build();
//	    
//	    try {
//	        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
//	        if (response.statusCode() == 200) {
//	            String responseBody = response.body();
//	            
//	            ObjectMapper objectMapper = new ObjectMapper();
//	            SpecificVolume specificVolume = objectMapper.readValue(responseBody, SpecificVolume.class);
//	            
//	            return specificVolume;
//	        } else {
//	            throw new GoogleBookAPIException("Error: Received HTTP status code " + response.statusCode());
//	        }
//	    } catch (IOException e) {
//	        throw new GoogleBookAPIException("Error requesting data from the Google Books API.", e);
//	    }
//	}
	
	

	// 3rd Method-SearchHistory
	public static class SearchHistory {
		private LinkedList<String> searchQueries = new LinkedList<String>();
	    private final int maxSize = 5;

	    // Add a search query to the history
	    public void addSearchQuery(String query) {
	        if (searchQueries.size() >= maxSize) {
	        	// Remove the oldest query if the list reaches the maximum size
	            searchQueries.removeLast(); 
	        }
	        searchQueries.addFirst(query);
	    }

	    // Get the search history
	    public List<String> getSearchHistory() {
	    // Return a copy to prevent external modification
	    return new LinkedList<String>(searchQueries); 
	    }
	}

	
	// 4th Method Retrieve a list of user's public bookshelves
	// https://www.googleapis.com/books/v1/users/1112223334445556677/bookshelves&key=yourAPIKey

	public userBookshelf getBookshelves(String userId) throws GoogleBookAPIException, InterruptedException {
		String apiBaseUrl = "https://www.googleapis.com/books/v1/users/";

	    String uri = apiBaseUrl + userId + "/bookshelves" + "?key=" + API_KEY;

	    HttpClient httpClient = HttpClient.newHttpClient();
	    HttpRequest request = HttpRequest.newBuilder()
	            .uri(URI.create(uri))
	            .build();

	    try {
	        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
	        if (response.statusCode() == 200) {
	            String responseBody = response.body();

	            ObjectMapper objectMapper = new ObjectMapper();
	            userBookshelf bookshelvesResult = objectMapper.readValue(responseBody, userBookshelf.class);

	            return bookshelvesResult;
	        } else {
	            throw new GoogleBookAPIException("Error: Received HTTP status code " + response.statusCode());
	        }
	    } catch (IOException e) {
	        throw new GoogleBookAPIException("Error requesting data from the Google Books API.", e);
	    }
	}

	
	
	// 5th Method Retrieve contents of a user's public bookshelves
	// https://www.googleapis.com/books/v1/users/1112223334445556677/bookshelves/3?key=yourAPIKey

	public SpecificPublicBookshelf getSpecificBookshelf(String userId, String bookshelfId)
			throws GoogleBookAPIException, IOException, InterruptedException {
		 String apiBaseUrl = "https://www.googleapis.com/books/v1/users/";

		    int id = 0;
		    if (bookshelfId.equals("1001")) {
		        id = 1001;
		    } else if (bookshelfId.equals("0")) {
		        id = 0;
		    } else {
		        throw new IllegalArgumentException("bookshelfId must be either \"1001\" or \"0\"");
		    }

		    String uri = apiBaseUrl + userId + "/bookshelves/" + id + "?key=" + API_KEY;

		    HttpClient httpClient = HttpClient.newHttpClient();
		    HttpRequest request = HttpRequest.newBuilder()
		            .uri(URI.create(uri))
		            .build();

		    try {
		        HttpResponse<String> response = httpClient.send(request, HttpResponse.BodyHandlers.ofString());
		        if (response.statusCode() == 200) {
		            String responseBody = response.body();

		            ObjectMapper objectMapper = new ObjectMapper();
		            SpecificPublicBookshelf specificBookshelf = objectMapper.readValue(responseBody, SpecificPublicBookshelf.class);

		            return specificBookshelf;
		        } else {
		            throw new GoogleBookAPIException("Error: Received HTTP status code " + response.statusCode());
		        }
		    } catch (IOException e) {
		        throw new GoogleBookAPIException("Error requesting data from the Google Books API.", e);
		    }
		}



	// 6th Method Retrieve contents of a user's public bookshelves
	// https://www.googleapis.com/books/v1/users/1112223334445556677/bookshelves/3/volumes?key=yourAPIKey
	public ListVolumesBookshelf getVolumesFromBookshelf(String userId, String bookshelfId) throws GoogleBookAPIException {
		String apiBaseUrl = "https://www.googleapis.com/books/v1/users/";
		int id = 0;
		if (bookshelfId.equals("1001")) {
			id = 1001;
		}
		String uri = apiBaseUrl + userId + "/bookshelves/" + id + "/volumes" + "?key=" + API_KEY;

		final HttpGet getRequest = new HttpGet(uri);
		final CloseableHttpClient httpClient = HttpClients.createDefault();
		try {
			CloseableHttpResponse response = httpClient.execute(getRequest);
			final HttpEntity entity = response.getEntity();
			final ObjectMapper mapper = new ObjectMapper();

			if (response.getStatusLine().getStatusCode() != HttpStatus.SC_OK) {
				ErrorResponse errorResponse = mapper.readValue(entity.getContent(), ErrorResponse.class);
				if (errorResponse.getStatusMessage() != null)
					throw new GoogleBookAPIException("Error occurred on API call: " + errorResponse.getStatusMessage());
			}

			final ListVolumesBookshelf volumeList = mapper.readValue(entity.getContent(), ListVolumesBookshelf.class);
			return volumeList;
		} catch (IOException e) {
			throw new GoogleBookAPIException("Error requesting data from the Google Books API.", e);
		}

	}
}
