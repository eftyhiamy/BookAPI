import java.util.List;
import java.util.Scanner;
import model.specificVolume.SpecificVolume;
import exception.GoogleBookAPIException;
import model.googleBookshelves.Item;
import model.googleBookshelves.userBookshelf;
import model.listBookshelf.ListVolumesBookshelf;
import model.TheBookDB.BookResult;
import services.GoogleBookAPIServices;
import services.GoogleBookAPIServices.SearchHistory;

public class Application {
    public static void main(String[] args) throws InterruptedException {
        Scanner scanner = new Scanner(System.in);
        GoogleBookAPIServices api = new GoogleBookAPIServices();
        SearchHistory searchHistory = new SearchHistory();

        System.out.println("Welcome to GoogleBookAPI!");
        System.out.println();

        while (true) {
            displayMenu();
            String input = scanner.nextLine();

            if ("1".equals(input)) {
                searchBooks(api, searchHistory, scanner);
            } else if ("2".equals(input)) {
                showVolumeInfo(api, searchHistory, scanner);
            } else if ("3".equals(input)) {
                showSearchHistory(searchHistory);
            } else if ("4".equals(input)) {
                listUserBookshelves(api, scanner);
            } else if ("5".equals(input)) {
                listContentsOfBookshelf(api, scanner);
            } else if ("6".equals(input)) {
                exitApplication(scanner);
            } else {
                System.out.println("Invalid input");
            }
        }
    }

    private static void displayMenu() {
        System.out.println();
        System.out.println("Please select one from the following options: ");
        System.out.println("1. Retrieve books using criteria.");
        System.out.println("2. Show info for a specific volume.");
        System.out.println("3. Show search history.");
        System.out.println("4. Retrieve a list of user's public bookshelves.");
        System.out.println("5. Retrieve contents of a user's public bookshelves.");
        System.out.println("6. Exit.");
        System.out.print("Your choice: ");
    }
    
    // Option 1: Search for books using criteria
    private static void searchBooks(GoogleBookAPIServices api, SearchHistory searchHistory, Scanner scanner) throws InterruptedException {
    	System.out.println("Enter the book title (leave no space): ");
        String bookTitle = scanner.nextLine();
        System.out.println();

        System.out.println("Enter the book terms: ");
        System.out.println("The available terms are: ");
        System.out.println("intitle");
        System.out.println("inauthor");
        System.out.println("inpublisher");
        System.out.println("subject");
        System.out.println("isbn");
        System.out.println("lccn");
        System.out.println("oclc");
        System.out.print("Your choice: ");
        String terms = scanner.nextLine();
        System.out.println();

        System.out.println("Enter the book specific terms: ");
        String specificTerms = scanner.nextLine();
        System.out.println();

        try {
            // Call the API to search for books
            BookResult result = api.getVolumes(bookTitle, terms, specificTerms);
            
            // Display the search result
            System.out.println(result.toString());
            
            // Add the search query to the search history
            searchHistory.addSearchQuery(bookTitle);
        } catch (GoogleBookAPIException e) {
            System.err.println("Error occurred: " + e.getMessage());
        }
    }

    // Option 2: Show information for a specific volume
    private static void showVolumeInfo(GoogleBookAPIServices api, SearchHistory searchHistory, Scanner scanner) throws InterruptedException {
    	System.out.println("Enter the volume ID:");
        String volumeId = scanner.nextLine();
        System.out.println();

        try {
            // Call the API to get information for the specific volume
            SpecificVolume volumeInfo = api.getSpecificVolume(volumeId);

            // Display volume information
            System.out.println("Title: " + volumeInfo.getVolumeInfo().getTitle());
            System.out.println("Author(s): " + volumeInfo.getVolumeInfo().getAuthors());
            System.out.println("Description: " + volumeInfo.getVolumeInfo().getDescription());
            System.out.println("Publisher: " + volumeInfo.getVolumeInfo().getPublisher());
            System.out.println("Published Date: " + volumeInfo.getVolumeInfo().getPublishedDate());
            System.out.println("Page Count: " + volumeInfo.getVolumeInfo().getPageCount());
            System.out.println("Language: " + volumeInfo.getVolumeInfo().getLanguage());
            System.out.println("Content Version: " + volumeInfo.getVolumeInfo().getContentVersion());
            System.out.println("Categories: " + volumeInfo.getVolumeInfo().getCategories());

            // Add the volume ID to the search history
            searchHistory.addSearchQuery(volumeId);
        } catch (GoogleBookAPIException e) {
            System.err.println("Error occurred: " + e.getMessage());
        }
    }

    // Option 3: Show search history
    private static void showSearchHistory(SearchHistory searchHistory) {
        List<String> searchHistoryList = searchHistory.getSearchHistory();
        System.out.println("Search history:");
        for (String searchQuery : searchHistoryList) {
            System.out.println(searchQuery);
        }
    }

    // Option 4: Retrieve a list of user's public bookshelves
    private static void listUserBookshelves(GoogleBookAPIServices api, Scanner scanner) throws InterruptedException {
    	 System.out.println("Enter the user ID:");
         String userId = scanner.nextLine();

         try {
             // Call the API to get the user's bookshelves
             userBookshelf bookshelvesResult = api.getBookshelves(userId);

             // Display user's bookshelves
             System.out.println("User bookshelves: ");
             for (Item item : bookshelvesResult.getItems()) {
                 System.out.println(item);
             }
         } catch (GoogleBookAPIException e) {
             System.err.println("Error occurred: " + e.getMessage());
         }
    }

    // Option 5: Retrieve contents of a user's public bookshelves
    private static void listContentsOfBookshelf(GoogleBookAPIServices api, Scanner scanner) {
    	System.out.println("Enter the user ID:");
        String userId = scanner.nextLine();
        System.out.println("Enter the bookshelf ID:");
        String bookshelfId = scanner.nextLine();

        if (bookshelfId.equals("1001")) {
            try {
                // Call the API to get the contents of the bookshelf
                ListVolumesBookshelf volumeList = api.getVolumesFromBookshelf(userId, bookshelfId);

                // Display the contents of the bookshelf
                System.out.println("Bookshelf contents: ");
                for (model.listBookshelf.Item item : volumeList.getItems()) {
                    System.out.println(item);
                }
            } catch (GoogleBookAPIException e) {
                System.err.println("Error occurred: " + e.getMessage());
            }
        } else {
            System.err.println("Invalid bookshelf ID or User ID.");
        }
    }

    // Option 6: Exit
    private static void exitApplication(Scanner scanner) {
        System.out.println("Exiting...");
        System.out.println("Thanks for using GoogleBookAPI!");
        scanner.close();
        System.exit(0);
    }
}