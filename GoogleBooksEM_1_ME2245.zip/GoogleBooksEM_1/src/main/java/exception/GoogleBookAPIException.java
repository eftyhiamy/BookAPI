package exception;


public class GoogleBookAPIException extends Exception{
	
		public GoogleBookAPIException() {
				super();
		}

		public GoogleBookAPIException(String message) {
				super(message);
		}
	
		public GoogleBookAPIException(String message, Throwable cause) {
				super(message,cause);
		}
		public GoogleBookAPIException(Throwable cause) {
				super(cause);
	
		}
	
		protected GoogleBookAPIException(String message, Throwable cause, boolean enableSuppression, boolean writableStackTrace) {
				super(message,cause,enableSuppression,writableStackTrace);
		}
}
