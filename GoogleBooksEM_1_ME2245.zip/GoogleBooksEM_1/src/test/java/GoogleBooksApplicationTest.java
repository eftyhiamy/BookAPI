import static org.junit.Assert.*;

import java.io.IOException;
import java.io.PrintWriter;
import java.io.StringWriter;

import org.junit.Before;
import org.junit.Test;

import exception.GoogleBookAPIException;
import model.TheBookDB.BookResult;
import model.googleBookshelves.userBookshelf;
import model.listBookshelf.ListVolumesBookshelf;
import model.specificBookshelves.SpecificPublicBookshelf;
import model.specificVolume.SpecificVolume;
import services.GoogleBookAPIServices;

public class GoogleBooksApplicationTest {
	
	@Test
	public void testGetVolumes() throws GoogleBookAPIException, InterruptedException {
		
		 String bookName = "Sample Book";
	     String terms = "intitle";
	     String SpecificTerms = "Author Name";
	     
	     try {
	    	 GoogleBookAPIServices api = new GoogleBookAPIServices();
	    	 BookResult result = api.getVolumes(bookName, terms, SpecificTerms);
	            assertNotNull(result);
	        } catch (GoogleBookAPIException e) {
	            fail("An unexpected exception occurred: " + e.getMessage());
	        }
	     }
	
	@Test
	public void testGetSpecificVolume() throws GoogleBookAPIException, InterruptedException {
		
		String volumeId = "Sample volume";
		
		try {
			GoogleBookAPIServices api = new GoogleBookAPIServices();
	    	SpecificVolume result = api.getSpecificVolume(volumeId);
	            assertNotNull(result);
	        } catch (GoogleBookAPIException e) {
	            fail("An unexpected exception occurred: " + e.getMessage());
	        }
		}
	
	@Test
	public void testGetBookshelves() throws GoogleBookAPIException, InterruptedException {
		
		String userId = "userID";
		
		try {
			GoogleBookAPIServices api = new GoogleBookAPIServices();
	    	userBookshelf result = api.getBookshelves(userId);
	            assertNotNull(result);
	        } catch (GoogleBookAPIException e) {
	            fail("An unexpected exception occurred: " + e.getMessage());
	        }
		}
	
	@Test
	public void testSpecificBookshef() throws GoogleBookAPIException, InterruptedException {
		
		String userId = "user ID";
		String bookshelfId = "Bookshelf ID";
		
		try {
			GoogleBookAPIServices api = new GoogleBookAPIServices();
			SpecificPublicBookshelf result = api.getSpecificBookshelf(userId, bookshelfId);
	            assertNotNull(result);
	        } catch (GoogleBookAPIException e) {
	            fail("An unexpected exception occurred: " + e.getMessage());
	        } catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
	
	@Test
	public void testGetVolumesFromBookshelf() throws GoogleBookAPIException {
		
		String userId = "userID";
		String bookshelfId = "Bookshelf ID";
		
		try {
			GoogleBookAPIServices api = new GoogleBookAPIServices();
	    	ListVolumesBookshelf result = api.getVolumesFromBookshelf(userId, bookshelfId);
	            assertNotNull(result);
	        } catch (GoogleBookAPIException e) {
	            fail("An unexpected exception occurred: " + e.getMessage());
	        }
		}
}
